import React from "react";
import axios from "axios";

const LeaveApproval =()=>{

    return(
        
        <div className="section">
            
            <h1>Leave Approve</h1>


            
            
            
        </div>
    )

}

        



export default LeaveApproval;