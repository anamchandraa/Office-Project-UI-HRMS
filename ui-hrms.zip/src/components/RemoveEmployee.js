import React,{useeEffect} from "react";
import axios from "axios";


const RemoveEmployee =()=>{




    return(
        <div><hi>hello</hi></div>
    )
}

export default RemoveEmployee;


