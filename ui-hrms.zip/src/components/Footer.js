const Footer = () => {
  return (
    <div>
      <footer id="footer" className="footer">
         {/* <div className="copyright">
          &copy; Allright{" "}
          <strong>
            <span>Unifier</span>
          </strong>. All Rights Reserved
        </div>
        <div className="credits">
          Designed by <a href="#">Unifier</a>
        </div>  */}
      </footer>
    </div>
  );
};
export default Footer;
